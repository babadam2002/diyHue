def set_light(light, data):
    pass
