from lights.protocols import wled, hyperion, yeelight, tasmota, shelly, mi_box, hue, deconz, domoticz, tradfri, native, native_single, native_multi, esphome, mqtt, wiz, milight, homeassistant_ws, tpkasa, hue_bl, elgato, dummy

protocols = [wled, hyperion, yeelight, tasmota, shelly, mi_box, hue, deconz, domoticz, tradfri, native, native_single, native_multi, esphome, mqtt, wiz, milight, homeassistant_ws, tpkasa, hue_bl, elgato, dummy]
