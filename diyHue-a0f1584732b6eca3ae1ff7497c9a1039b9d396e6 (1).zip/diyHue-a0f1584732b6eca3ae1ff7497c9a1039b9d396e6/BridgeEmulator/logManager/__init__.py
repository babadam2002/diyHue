from logManager import logger

logger = logger.Logger()
